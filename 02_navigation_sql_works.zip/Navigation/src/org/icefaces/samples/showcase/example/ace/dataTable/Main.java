package org.icefaces.samples.showcase.example.ace.dataTable;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;


public class Main {
	
	public static final void main(String[] args){
		EntityManagerFactory factory = Persistence.createEntityManagerFactory("manager1");
		EntityManager em = factory.createEntityManager();
		em.getTransaction().begin();
		
		// Add line to database
		em.persist(new Scheduling("DERP", "MEGAHERP", "0", 0, 0));
		
		// SELECT query
		Query q = em.createQuery("from Scheduling where id = 2001");
		
		List<Scheduling> results = q.getResultList();
		
		for (Scheduling scheduling : results) {
			System.out.println(scheduling.getName());
		}
			
		// Fetch single JPA object and remove it
		Scheduling  s = em.find(Scheduling.class, 2001);
		em.remove(s);
		
		// DELETE query
		em.createQuery("DELETE FROM Scheduling WHERE id > 2000").executeUpdate();
		
		em.getTransaction().commit();
		em.close();
	}
	
}
