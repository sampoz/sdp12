/*
 * Copyright 2004-2012 ICEsoft Technologies Canada Corp.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the
 * License. You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an "AS
 * IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
 * express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */

package org.icefaces.samples.showcase.example.ace.dataTable;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

@Entity
@Table(name = "SCHEDULING")
public class Schedule  {
	@Id
	@GeneratedValue(generator = "increment")
	@GenericGenerator(name = "increment", strategy = "increment")
	protected int id;
	@Column(name = "NAME")
	protected String name;
	
	@Column(name = "DESCRIPTION")
	private String description;
	
	@Column(name = "CRON")
	private String cron;
	
	@Column(name = "REQUESTURL")
	private String requestURL;

	@Column(name = "BANKHOLIDAYONLY")
	private Integer bankHolidayOnly;

	@Column(name = "SERVICEID")
	private Integer serviceID;

	@Column(name = "STATUSID")
	private Integer statusID;

	@Column(name = "JAVAAGENTPOLLABLE")
	private Integer javaAgentPollable;

	public Schedule() {
	}

	public Schedule(int id, String name, String chassis, int weight,
			int acceleration, double mpg, double cost) {
		this.id = id;
		this.name = name;
		
	}
	public Schedule(String name, String description, String cron,
			int serviceID, int statusID) {
		super();
		this.name = name;
		this.description = description;
		this.cron = cron;
		this.serviceID = serviceID;
		this.statusID = statusID;
		this.bankHolidayOnly = 0;
	}

	public int getId() {
		return id;
	}


	public void setId(int id) {
		this.id = id;
	}


	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public String getDescription() {
		return description;
	}


	public void setDescription(String description) {
		this.description = description;
	}


	public String getCron() {
		return cron;
	}


	public void setCron(String cron) {
		this.cron = cron;
	}


	public String getRequestURL() {
		return requestURL;
	}


	public void setRequestURL(String requestURL) {
		this.requestURL = requestURL;
	}


	public int getBankHolidayOnly() {
		return bankHolidayOnly;
	}


	public void setBankHolidayOnly(int bankHolidayOnly) {
		this.bankHolidayOnly = bankHolidayOnly;
	}


	public int getServiceID() {
		return serviceID;
	}


	public void setServiceID(int serviceID) {
		this.serviceID = serviceID;
	}


	public int getStatusID() {
		return statusID;
	}


	public void setStatusID(int statusID) {
		this.statusID = statusID;
	}


	public int getJavaAgentPollable() {
		return javaAgentPollable;
	}


	public void setJavaAgentPollable(int javaAgentPollable) {
		this.javaAgentPollable = javaAgentPollable;
	};
	

	public void applyValues(Schedule parent) {
		setId(parent.getId());
		setName(parent.getName());
		
	}

	public String toString() {
		return getName();
	}

	// Fix symptoms of session serialization issue when using TreeDataModel
	// by giving hashCode implementation to row objects.
	@Override
	public boolean equals(Object o) {
		if (this == o)
			return true;
		if (o == null || getClass() != o.getClass())
			return false;

		Schedule car = (Schedule) o;

		if (id != car.id)
			return false;
		if (!name.equals(car.name))
			return false;

		return true;
	}

	@Override
	public int hashCode() {
		int result = id;
		result = 31 * result + name.hashCode();
		return result;
	}
}
